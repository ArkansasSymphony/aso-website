from django import forms
from django.forms import extras, ModelForm
from arkansassymphony.donate.models import *

class ModelDonateForm(ModelForm):
	
	class Meta:
		model = Donate
