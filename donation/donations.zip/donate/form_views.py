from django.shortcuts import render_to_response
from django.core.mail import send_mail
from django.template import RequestContext
from django import forms
from arkansassymphony.donate.models import *
import stripe

def donate_formview(request):
	from django import forms
	from arkansassymphony.donate.forms import ModelDonateForm
	#stripe.api_key = "sk_live_5Sj3N6Pw2s9VlTvrDBfkKKh2" #live secret key
	stripe.api_key = "sk_test_LzACjJeSISN4levLs9PkYRTY" #test secret key
	
	if request.method == 'POST':
		form = ModelDonateForm(request.POST)

		token = request.POST['stripeToken'] #passed from stripe.js to keep card info off this server

		if form.is_valid():
			name = form.cleaned_data['name']
			donation = form.cleaned_data['donation']
			anonymous = form.cleaned_data['anonymous']
			email = form.cleaned_data['email']
			phone = form.cleaned_data['phone']
			address = form.cleaned_data['address']
			city = form.cleaned_data['city']
			state = form.cleaned_data['state']
			zip = form.cleaned_data['zip']
			notes = form.cleaned_data['notes']
			
			# Create the charge on Stripe's servers - this will charge the user's card
			charge = stripe.Charge.create(
				amount = donation*100, # convert dollars to cents
				currency = "usd",
				card = token,
				description = email
			)
			
			form.save()
			
			from django.core.mail import send_mail
			recipients = ['bdorris@arkansassymphony.org']
			
			subject = 'ONLINE DONATION RECEIVED'
			message = """
			
			An online gift was processed as follows:
			
			%s
			%s
			%s, %s %s
			%s
			
			Donation amount: $ %s
			Anonymous: %s
			Notes: %s
			
			""" % (name, address, city, state, zip, phone, str(donation), anonymous, notes)
			
			send_mail(subject, message, email, recipients)
			
			return render_to_response('donate/submitted.html', {'name': name, 'email': email, 'address': address, 'city': city, 'state': state, 'zip': zip, 'phone': phone, 'donation': donation, 'anonymous': anonymous, 'notes': notes}, context_instance=RequestContext(request)) #redirect after POST
	else:
		form = ModelDonateForm() #unbound form
		
	return render_to_response('donate/donate.html', {'form': form,}, context_instance=RequestContext(request))
