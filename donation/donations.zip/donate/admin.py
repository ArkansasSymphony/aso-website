from arkansassymphony.donate.models import *
from django.contrib import admin

class DonateAdmin(admin.ModelAdmin):
	list_display = ('name', 'donation', 'anonymous', 'email', 'notes')

admin.site.register(Donate, DonateAdmin)
